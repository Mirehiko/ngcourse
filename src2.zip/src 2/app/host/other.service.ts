import {Injectable} from "@angular/core";

@Injectable()
export class OtherService {
  toString() {
    return "I'm other service"
  }
}
