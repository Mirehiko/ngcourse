import {Component} from "@angular/core";
import {OtherService} from "./other.service";

@Component({
  selector: 'app-top',
  providers: [OtherService],
  template: '<app-parent></app-parent>',
})
export class TopComponent {}
