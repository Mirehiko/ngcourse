import {Component, Host, Optional, Self, SkipSelf} from "@angular/core";
import {OtherService} from "./other.service";
import {HostService} from "./host.service";
import {Other2Service} from "./other2.service";

@Component({
  selector: 'app-parent',
  template: '<child-directive></child-directive>',
  providers: [ OtherService ]
  // providers: [{provide: OtherService, useClass: Other2Service}]
})
export class ParentComponent {
  constructor(@Host() otherService: OtherService) {
    console.log("parent component @Host: "+otherService)
  }
}
