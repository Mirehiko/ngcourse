import {Injectable} from "@angular/core";

@Injectable()
export class Other2Service {
  toString() {
    return "I'm other 2 service"
  }
}
