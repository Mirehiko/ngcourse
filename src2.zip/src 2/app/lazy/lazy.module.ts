import { NgModule } from '@angular/core';
import {RandomLazyComponent} from './random.lazy.component';
import {LazyAppComponent} from './lazy.component';
import {RouterModule} from '@angular/router';
import {RandomService3} from "./random.service3";
import {LazyServiceModule} from "./lazy.service.module";
import {RandomService} from "../random.service";
import {HttpClient, HttpClientModule} from "@angular/common/http";
import {LazyService} from "./lazy.service";

@NgModule({
  declarations: [
    RandomLazyComponent,
    LazyAppComponent,
  ],
  imports: [
    RouterModule.forChild([
      { path: '', component: LazyAppComponent }
    ]),
    LazyServiceModule,
    HttpClientModule
  ],
  providers: [
      //LazyService,
    { provide: RandomService3, useExisting: RandomService }
  ]
})
export class LazyModule { }
