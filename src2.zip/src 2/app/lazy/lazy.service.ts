import {Injectable} from "@angular/core";
import {LazyServiceModule} from "./lazy.service.module";
import {LazyModule} from "./lazy.module";

@Injectable({ providedIn: LazyServiceModule })
//  @Injectable({ providedIn: LazyModule })
@Injectable()
export class LazyService {
}
