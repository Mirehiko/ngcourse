import {Injectable} from "@angular/core";
import {LazyServiceModule} from "./lazy.service.module";
import {LazyModule} from "./lazy.module";

@Injectable({providedIn: LazyModule})
export class RandomService3 {
  random: string;

  constructor() {
    this.random = Math.random().toFixed(3);
  }
}
