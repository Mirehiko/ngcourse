import {Inject, Injectable} from "@angular/core";
import {RandomTitleService} from "./random-title.service";
import {RANDOM_TITLE_SERVICES} from "./app.module";

@Injectable({providedIn: 'root'})
export class RandomService {
  random: string;
  title: string = "";

  constructor(@Inject(RANDOM_TITLE_SERVICES) randomTitleServices: RandomTitleService[]) {
    for (let randomTitleService of randomTitleServices) {
      this.title += randomTitleService.title;
    }
    this.random = Math.random().toFixed(1);
    console.log("creating Random Service " + this.random)
  }
}
