import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class RandomTitle2Service {
  title = 'random2: ';
  constructor() { }
}
